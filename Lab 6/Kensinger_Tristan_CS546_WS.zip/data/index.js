const bandsData = require('./bands');
const albumsData = require('./albums');

module.exports = {
  bands: bandsData,
  albums: albumsData
};