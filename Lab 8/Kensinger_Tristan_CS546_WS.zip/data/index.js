module.exports = {
    tv: require('./tv')
};