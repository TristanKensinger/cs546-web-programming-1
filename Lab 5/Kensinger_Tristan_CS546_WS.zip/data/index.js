//Code Credit to Patrick Hill's Lecture Code
const userData = require('./userApi');

module.exports = {
  users: userData
};